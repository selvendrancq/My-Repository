package com.adobe.aem.guides.wknd.core.services.impl;

import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import org.apache.commons.io.IOUtils;
import org.osgi.service.component.annotations.Component;

import com.adobe.aem.guides.wknd.core.services.PDFGenerationService;
import com.adobe.pdfservices.operation.PDFServices;
import com.adobe.pdfservices.operation.PDFServicesResponse;
import com.adobe.pdfservices.operation.auth.Credentials;
import com.adobe.pdfservices.operation.auth.ServicePrincipalCredentials;
import com.adobe.pdfservices.operation.io.Asset;
import com.adobe.pdfservices.operation.io.StreamAsset;
import com.adobe.pdfservices.operation.pdfjobs.jobs.HTMLToPDFJob;
import com.adobe.pdfservices.operation.pdfjobs.params.htmltopdf.HTMLToPDFParams;
import com.adobe.pdfservices.operation.pdfjobs.params.htmltopdf.PageLayout;
import com.adobe.pdfservices.operation.pdfjobs.result.HTMLToPDFResult;

@Component(service = PDFGenerationService.class)
public class PDFGenerationServiceImpl implements PDFGenerationService{

	@Override
	public void generatePDFFromUrl(String htmlURL) throws Exception {
		// TODO Auto-generated method stub
		 // Initial setup, create credentials instance
        Credentials credentials = new ServicePrincipalCredentials("", "");

        // Creates a PDF Services instance
        PDFServices pdfServices = new PDFServices(credentials);


        // Create parameters for the job
        HTMLToPDFParams htmlToPDFParams = getHTMLToPDFParams();
        
     // Creates a new job instance
        HTMLToPDFJob htmLtoPDFJob = new HTMLToPDFJob(htmlURL).setParams(htmlToPDFParams);

        // Submit the job and gets the job result
        String location = pdfServices.submit(htmLtoPDFJob);
        PDFServicesResponse<HTMLToPDFResult> pdfServicesResponse = pdfServices.getJobResult(location, HTMLToPDFResult.class);

        // Get content from the resulting asset(s)
        Asset resultAsset = pdfServicesResponse.getResult().getAsset();
        StreamAsset streamAsset = pdfServices.getContent(resultAsset);

        // Creates an output stream and copy stream asset's content to it
        String outputFilePath = createOutputFilePath();

        OutputStream outputStream = Files.newOutputStream(new File(outputFilePath).toPath());
        IOUtils.copy(streamAsset.getInputStream(), outputStream);
        outputStream.close();
        
        
		return;
	}

	 private static HTMLToPDFParams getHTMLToPDFParams() {
	        // Define the page layout, in this case an 8 x 11.5 inch page (effectively portrait orientation)
	        PageLayout pageLayout = new PageLayout();
	        pageLayout.setPageSize(8.26, 40);

	        return new HTMLToPDFParams.Builder()
	                .includeHeaderFooter(true)
	                .withPageLayout(pageLayout)
	                .build();
	    }

	    // Generates a string containing a directory structure and file name for the output file
	    public static String createOutputFilePath() throws IOException {
	        DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH-mm-ss");
	        LocalDateTime now = LocalDateTime.now();
	        String timeStamp = dateTimeFormatter.format(now);
	        Files.createDirectories(Paths.get("output/HTMLToPDFFromURL"));
	        return ("output/HTMLToPDFFromURL/htmltopdf" + timeStamp + ".pdf");
	    }
}
