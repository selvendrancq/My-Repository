package com.adobe.aem.guides.wknd.core.services;

public interface PDFGenerationService {
	void generatePDFFromUrl(String URL) throws Exception;
}
