package com.adobe.aem.guides.wknd.core.servlet;

import javax.servlet.Servlet;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

import com.adobe.aem.guides.wknd.core.services.PDFGenerationService;

@Component(service = Servlet.class, property = { "sling.servlet.methods=GET",
		"sling.servlet.paths=/bin/servlet/generatepdf" })
public class PDFGenerationServlet extends SlingAllMethodsServlet {

	/**
	* 
	*/
	private static final long serialVersionUID = 1L;
	@Reference
	private PDFGenerationService pdfGenerationService;

	@Override
	protected void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response) {
		String pageURL = "https://www.highcharts.com/demo/highcharts/spline-symbols";
		try {
			pdfGenerationService.generatePDFFromUrl(pageURL);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
